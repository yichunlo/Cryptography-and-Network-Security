Follow the report, as I think report explains enough.
